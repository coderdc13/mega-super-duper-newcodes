new_counter = 100
while new_counter > 0:
  print(new_counter)
  new_counter = new_counter - 1
while new_counter == 0:
  break
print("Boom!")